# Python imports
import logging

MovieLogger = logging.getLogger("movie_logger")
