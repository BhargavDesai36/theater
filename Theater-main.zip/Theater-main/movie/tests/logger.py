# Python imports
import logging

TestingLogger = logging.getLogger("movie_testcase")
