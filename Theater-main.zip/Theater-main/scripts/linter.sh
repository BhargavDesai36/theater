#!/bin/bash

pipenv run python -m ruff check .