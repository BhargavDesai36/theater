# Python imports
import logging

TestingLogger = logging.getLogger("user_testcase")
