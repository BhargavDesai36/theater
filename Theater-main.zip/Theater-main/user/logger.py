# Python imports
import logging

UserLogger = logging.getLogger("user_logger")
