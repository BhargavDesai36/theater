# Python imports
import logging

testing_logger = logging.getLogger("testing")
